---
title: "Opening Day"
date: 2025-01-03
---

We opened our doors — welcome!
