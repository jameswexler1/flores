---
title: "Sample — Classic Red Roses"
date: 2025-01-11
slug: "classic-red-roses"
price: 59
image: "/images/roses-classic.jpg"
---

A dozen fresh red roses, hand-tied and wrapped in kraft paper.
