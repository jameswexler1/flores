---
title: Luxe Orchid Pot
date: '2025-01-14'
slug: luxe-orchid
price: 79.0
image: /images/orchid.jpg
categories:
- plants
- premium
tags:
- orchid
- long-lasting
variants:
- id: orchid-single
  name: Single plant
  price: 79.0
  sku: LO-1
  stock: 6
---

Detailed description for Luxe Orchid Pot. Beautifully arranged and delivered fresh.
