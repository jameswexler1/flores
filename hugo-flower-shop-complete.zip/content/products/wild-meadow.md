---
title: Wild Meadow Arrangement
date: '2025-01-13'
slug: wild-meadow
price: 39.0
image: /images/meadow.jpg
categories:
- arrangements
tags:
- wild
- natural
variants:
- id: meadow-default
  name: Default
  price: 39.0
  sku: WM-1
  stock: 10
---

Detailed description for Wild Meadow Arrangement. Beautifully arranged and delivered fresh.
