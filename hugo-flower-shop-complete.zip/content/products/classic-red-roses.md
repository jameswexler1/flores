---
title: Classic Red Roses
date: '2025-01-11'
slug: classic-red-roses
price: 59.0
image: /images/roses-classic.jpg
categories:
- roses
- bestsellers
tags:
- romance
- valentine
variants:
- id: classic-roses-12
  name: 12 stems
  price: 59.0
  sku: CR-12
  stock: 20
- id: classic-roses-6
  name: 6 stems
  price: 39.0
  sku: CR-6
  stock: 10
---

Detailed description for Classic Red Roses. Beautifully arranged and delivered fresh.
