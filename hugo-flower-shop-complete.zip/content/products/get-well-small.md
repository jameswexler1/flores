---
title: "Get Well \u2014 Small"
date: '2025-01-15'
slug: get-well-small
price: 29.0
image: /images/get-well.jpg
categories:
- gifts
tags:
- get-well
- compact
variants:
- id: gw-small
  name: Small
  price: 29.0
  sku: GW-S
  stock: 25
- id: gw-large
  name: Large
  price: 45.0
  sku: GW-L
  stock: 10
---

Detailed description for Get Well — Small. Beautifully arranged and delivered fresh.
