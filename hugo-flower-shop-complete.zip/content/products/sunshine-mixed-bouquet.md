---
title: Sunshine Mixed Bouquet
date: '2025-01-12'
slug: sunshine-mixed-bouquet
price: 45.0
image: /images/sunshine.jpg
categories:
- mixed
tags:
- cheerful
- summer
variants:
- id: sunshine-small
  name: Small
  price: 35.0
  sku: SS-S
  stock: 12
- id: sunshine-large
  name: Large
  price: 45.0
  sku: SS-L
  stock: 8
---

Detailed description for Sunshine Mixed Bouquet. Beautifully arranged and delivered fresh.
