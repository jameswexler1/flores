---
title: "Shop — Demo"
---

The demo shop lists products from the theme's data file.
